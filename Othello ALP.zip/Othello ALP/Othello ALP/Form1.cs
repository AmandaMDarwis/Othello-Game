using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Othello_ALP
{
    public partial class Form1 : Form
    {
        private const int BoardSize = 8;
        private Panel[,] boardPanels = new Panel[BoardSize, BoardSize];
        public Player player1;
        public Player player2;

        public Player currentPlayer;
        public Player enemy;
        public bool ShouldClose;
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyPress += new KeyPressEventHandler(Form1_KeyPress);
        }

        public struct Coordinate
        {
            public int X;
            public int Y;

            public Coordinate(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        List<Coordinate> grayPanelsCoordinates = new List<Coordinate>();

       
        private void Form1_Load(object sender, EventArgs e)
        {
            currentPlayer = player1;
            enemy = player2;
            // Set up the form
            this.Text = "Othello Board";
            this.Size = new Size(400, 430);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Create the board panels
            int cellSize = this.ClientSize.Width / BoardSize;
            for (int i = 0; i < BoardSize; i++)
            {
                for (int j = 0; j < BoardSize; j++)
                {
                    Panel panel = new Panel
                    {
                        Size = new Size(cellSize, cellSize),
                        Location = new Point(j * cellSize, i * cellSize),
                        BorderStyle = BorderStyle.Fixed3D,
                        BackColor = Color.Beige,
                    };
                    boardPanels[i, j] = panel;
                    this.Controls.Add(panel);
                }
            }

            //Set warna awal
            boardPanels[3, 3].BackColor = Color.White;
            boardPanels[3, 4].BackColor = Color.Black;
            boardPanels[4, 3].BackColor = Color.Black;
            boardPanels[4, 4].BackColor = Color.White;
            Search();

            for (int i = 0; i < BoardSize; i++)
            {
                for (int j = 0; j < BoardSize; j++)
                {
                    if (boardPanels[i, j].BackColor == Color.Gray)
                    {
                        grayPanelsCoordinates.Add(new Coordinate(i, j));
                    }
                }
            }
            UpdatePanelSelection();
        }

        int currentIndex = 0; 
        int resetI = 0; 
        int resetJ = 0; 
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'd')
            {
                if (grayPanelsCoordinates.Count == 0)
                {
                    return;
                }
                else
                {
                    currentIndex = (currentIndex + 1) % grayPanelsCoordinates.Count;
                    if (currentIndex == 0)
                    {
                        resetI = grayPanelsCoordinates[grayPanelsCoordinates.Count - 1].X;
                        resetJ = grayPanelsCoordinates[grayPanelsCoordinates.Count - 1].Y;
                    }
                    else
                    {
                        resetI = grayPanelsCoordinates[(currentIndex - 1) % grayPanelsCoordinates.Count].X;
                        resetJ = grayPanelsCoordinates[(currentIndex - 1) % grayPanelsCoordinates.Count].Y;
                    }
                    UpdatePanelSelection();
                }
                
            }
            else if (e.KeyChar == 'a')
            {
                if (grayPanelsCoordinates.Count == 0)
                {
                    return;
                }
                else
                {
                    if (currentIndex == 0)
                    {
                        resetI = grayPanelsCoordinates[currentIndex].X;
                        resetJ = grayPanelsCoordinates[currentIndex].Y;
                        currentIndex = grayPanelsCoordinates.Count - 1;
                        UpdatePanelSelection();
                    }
                    else
                    {
                        currentIndex = (currentIndex - 1) % grayPanelsCoordinates.Count;
                        resetI = grayPanelsCoordinates[currentIndex + 1].X;
                        resetJ = grayPanelsCoordinates[currentIndex + 1].Y;
                        UpdatePanelSelection();
                    }
                }
                    
            }

            // Menggunakan spasi sebagai trigger untuk giliran pemain
            if (e.KeyChar == ' ') // Ganti dengan tombol yang Anda inginkan
            {
                e.Handled = true; // Menghentikan karakter spasi dari ditambahkan ke kontrol
                bool status = false;
                if (grayPanelsCoordinates.Count > 0)
                {
                    int x = grayPanelsCoordinates[currentIndex].X;
                    int y = grayPanelsCoordinates[currentIndex].Y;
                    for (int i = 0; i < BoardSize; i++)
                    {
                        if (status)
                        {
                            break;
                        }
                        for (int j = 0; j < BoardSize; j++)
                        {
                            if ((boardPanels[x, y].BackColor == Color.Blue))
                            {
                                Reset();
                                if (currentPlayer == player1)
                                {
                                    boardPanels[x, y].BackColor = currentPlayer.PlayersColor;
                                    CheckEnemy(x, y);
                                    currentPlayer = player2;
                                    enemy = player1;
                                    Search();
                                }
                                else
                                {
                                    boardPanels[x, y].BackColor = currentPlayer.PlayersColor;
                                    CheckEnemy(x, y);
                                    currentPlayer = player1;
                                    enemy = player2;
                                    Search();
                                }
                                status = true;
                                break;
                            }
                        }
                    }

                    for (int i = 0; i < BoardSize; i++)
                    {
                        for (int j = 0; j < BoardSize; j++)
                        {
                            if (boardPanels[i, j].BackColor == Color.Gray)
                            {
                                grayPanelsCoordinates.Add(new Coordinate(i, j));
                            }
                        }
                    }
                    currentIndex = 0;
                    UpdatePanelSelection();
                }
                else
                {
                    return;
                }
            }

        }

        private void UpdatePanelSelection()
        {
            // Reset warna panel rekomendasi aktif (Blue) menjadi rekomendasi tidak aktif (Gray)
            if (boardPanels[resetI, resetJ].BackColor == Color.Blue)
            {
                boardPanels[resetI, resetJ].BackColor = Color.Gray;
            }

            if (grayPanelsCoordinates.Count == 0)
            {
                bool win = true;
                for (int i = 0; i < BoardSize; i++)
                {
                    for (int j = 0; j < BoardSize; j++)
                    {
                        if (boardPanels[i, j].BackColor == Color.Beige)
                        {
                            win = false;
                        }
                    }
                }
                if (win == true)
                {
                    int counterPutih = 0;
                    int counterHitam = 0;
                    for (int i = 0; i < BoardSize; i++)
                    {
                        for (int j = 0; j < BoardSize; j++)
                        {
                            if (boardPanels[i, j].BackColor == Color.White)
                            {
                                counterPutih++;
                            }
                            else if (boardPanels[i, j].BackColor == Color.Black)
                            {
                                counterHitam++;
                            }
                        }
                    }
                    if (counterHitam > counterPutih)
                    {
                        MessageBox.Show(player1.Name + " (Black) Wins\n(Black/White) : (" + counterHitam + "/" + counterPutih + ")");
                    }
                    else
                    {
                        MessageBox.Show(player2.Name + " (White) Wins\n(White/Black) : (" + counterPutih + "/" + counterHitam + ")");
                    }
                    this.Close();
                    return;
                }
                MessageBox.Show("No more valid moves! Switch turns!");
                Reset();
                if (currentPlayer == player1)
                {
                    currentPlayer = player2;
                    enemy = player1;
                    Search();
                }
                else
                {
                    currentPlayer = player1;
                    enemy = player2;
                    Search();
                }
                for (int i = 0; i < BoardSize; i++)
                {
                    for (int j = 0; j < BoardSize; j++)
                    {
                        if (boardPanels[i, j].BackColor == Color.Gray)
                        {
                            grayPanelsCoordinates.Add(new Coordinate(i, j));
                        }
                    }
                }
                UpdatePanelSelection();
            }
            else
            {
                // Dapatkan nilai i dan j dari indeks saat ini
                int x = grayPanelsCoordinates[currentIndex].X;
                int y = grayPanelsCoordinates[currentIndex].Y;

                if (boardPanels[x, y].BackColor == Color.Gray)
                {
                    boardPanels[x, y].BackColor = Color.Blue;
                }
            }
        }


        //search semua kotak yang sesuai dengan current player, sehinggA dapat cari kotak enemy di sekitarnya
        private void Search()
        {
            for (int i=0;i<BoardSize;i++)
            {
                for (int j=0;j<BoardSize;j++)
                {
                    if (currentPlayer == player1)
                    {
                        if (boardPanels[i,j].BackColor == currentPlayer.PlayersColor)
                        {
                            SearchEnemyAround(i, j);
                        }
                    }
                    else
                    {
                        if (boardPanels[i,j].BackColor == currentPlayer.PlayersColor)
                        {
                            SearchEnemyAround(i, j);
                        }
                    }
                }
            }
        }

        //Search enemy di sekitar current player, jika ditemukan maka selanjutnya akan
        //dipanggil function RecommendationEmptySpace untuk dicari tempat yang kosong
        private void SearchEnemyAround(int row, int column)
        {
            for (int i=-1;i<=1;i++)
            {
                for (int j=-1;j<=1;j++)
                {
                    int curRow = row + i;
                    int curColumn = column + j;
                    if (curRow < BoardSize && curRow >= 0 && curColumn < BoardSize && curColumn >= 0)
                    {
                        if ((curRow) == row && (curColumn) == column)
                        {
                            continue;
                        }
                        if (currentPlayer == player1)
                        {
                            if (boardPanels[(curRow), (curColumn)].BackColor == enemy.PlayersColor)
                            {
                                RecommendationEmptySpace(row, column, i, j);
                            }
                        }
                        else
                        {
                            if (boardPanels[(curRow), (curColumn)].BackColor == enemy.PlayersColor)
                            {
                                RecommendationEmptySpace(row, column, i, j);

                            }
                        }
                    }
                }
            }
        }

        // Digunakan untuk mencari tempat2 yang kosong utk dijadikan rekomendasi
        // langkah selanjutnya dari current player

        // dir row dir col untuk menntukan arahnya kemana bisa diagnoal kiri, kanan, dll.
        private void RecommendationEmptySpace(int row, int column, int dirRow, int dirCol)
        {
            int currentRow = row + dirRow;
            int currentCol = column + dirCol;
            while (boardPanels[currentRow,currentCol].BackColor == enemy.PlayersColor && 
                currentRow < BoardSize && currentRow >= 0 && 
                currentCol < BoardSize && currentCol>=0)
            {
                currentRow += dirRow;
                currentCol += dirCol;
                if (currentRow >= BoardSize || currentRow < 0 || currentCol >= BoardSize || currentCol < 0)
                {
                    break;
                }
            }
            if (currentRow < BoardSize && currentRow >= 0 && currentCol < BoardSize && currentCol >= 0
                && boardPanels[currentRow, currentCol].BackColor == Color.Beige)
            {
                 boardPanels[currentRow,currentCol].BackColor = Color.Gray;
            }
        }

        // Menghapus semua rekomendasi yang berwarna abu2 
        private void Reset()
        {
            grayPanelsCoordinates.Clear();
            currentIndex = 0;
            for (int i = 0; i < BoardSize; i++)
            {
                for (int j = 0; j < BoardSize; j++)
                {
                    if (boardPanels[i, j].BackColor != Color.Black && boardPanels[i, j].BackColor != Color.White)
                    {
                        boardPanels[i, j].BackColor = Color.Beige;
                    }
                }
            }
        }

        //Untuk mengecek enemy di sekitar panel abu2 yg dipilih
        //yang nantinya akan digunakan untuk cek titik trakir yg mengandung warna sesuai dengan current player
        //sehingga enemy di tengah2nya akan di flip
        private void CheckEnemy(int row, int col)
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int curRow = row + i;
                    int curColumn = col + j;
                    if (curRow < BoardSize && curRow >= 0 && curColumn < BoardSize && curColumn >= 0)
                    {
                        if ((curRow) == row && (curColumn) == col)
                        {
                            continue;
                        }
                        if (currentPlayer == player1)
                        {
                            if (boardPanels[(curRow), (curColumn)].BackColor == enemy.PlayersColor)
                            {
                                CheckColorCurrentPlayer(row, col, i, j);
                            }
                        }
                        else
                        {
                            if (boardPanels[(curRow), (curColumn)].BackColor == enemy.PlayersColor)
                            {
                                CheckColorCurrentPlayer(row, col, i, j);

                            }
                        }
                    }
                }
            }
        }

        //untuk cek titik trakir color yg sesuai dgn current player, sehingga warna enemy yg beraada
        // di antara panel current player dapat di flip
        private void CheckColorCurrentPlayer(int row, int col, int dirRow, int dirCol)
        {
            int currentRow = row + dirRow;
            int currentCol = col + dirCol;
            bool status = false;
            while (boardPanels[currentRow, currentCol].BackColor == enemy.PlayersColor && currentRow < BoardSize && currentRow >= 0 && currentCol < BoardSize && currentCol >= 0)
            {
                currentRow += dirRow;
                currentCol += dirCol;
                if (currentRow >= BoardSize || currentRow < 0 || currentCol >= BoardSize || currentCol < 0)
                {
                    break;
                }
                else if(currentPlayer.PlayersColor == boardPanels[currentRow, currentCol].BackColor)
                {
                    status = true;
                    break;
                }
            }
            if (currentRow < BoardSize && currentRow >= 0 && currentCol < BoardSize && currentCol >= 0 && status == true)
            {
                Flip(row, col, dirRow, dirCol);
            }
        }

        //Membalik warna enemy yg berda di antara panel currentplayer
        private void Flip(int row, int col, int dirRow, int dirCol)
        {
            int currentRow = row + dirRow;
            int currentCol = col + dirCol;
            bool status = false;
            while (boardPanels[currentRow, currentCol].BackColor == enemy.PlayersColor && currentRow < BoardSize && 
                currentRow >= 0 && currentCol < BoardSize && currentCol >= 0)
            {
                boardPanels[currentRow, currentCol].BackColor = currentPlayer.PlayersColor;
                currentRow += dirRow;
                currentCol += dirCol;
                if (currentRow >= BoardSize || currentRow < 0 || currentCol >= BoardSize || currentCol < 0)
                {
                    break;
                }
            }
        }

        private void  buttonClose_Click(object sender, EventArgs e)
        {
            ShouldClose = true;
        }
    }
}