﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Othello_ALP
{
    public class Player
    {
        private Color playersColor;
        private string name;
        private int score;
        private string sign;

        public Player(string name, string sign, Color playersColor)
        {
            this.Name = name;
            this.Score = 0;
            this.Sign = sign;
            this.PlayersColor = playersColor;
        }

        public string Name { get => name; set => name = value; }
        public int Score { get => score; set => score = value; }
        public string Sign { get => sign; set => sign = value; }
        public Color PlayersColor { get => playersColor; set => playersColor = value; }
    }
}
