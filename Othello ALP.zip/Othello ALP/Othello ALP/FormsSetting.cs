﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Othello_ALP
{
    public partial class FormsSetting : Form
    {
        Player player1 = null;
        Player player2 = null;

        public FormsSetting()
        {
            InitializeComponent();
        }

        //private void btnEnter1_Click(object sender, EventArgs e)
        //{
        //    string p1Name = txtNameP1.Text;
        //    string p2Name = txtNameP2.Text;
        //    player1 = new Player(p1Name, "X", Color.Black);
        //    player2 = new Player(p2Name, "O", Color.White);

        //}

        private void btnStart_Click(object sender, EventArgs e)
        {
            string p1Name = txtNameP1.Text;
            string p2Name = txtNameP2.Text;
            player1 = new Player(p1Name, "X", Color.Black);
            player2 = new Player(p2Name, "O", Color.White);

            Form1 frm = new Form1();
            frm.player1 = player1;
            frm.player2 = player2;
            frm.ShowDialog();

           
        }
    }
}
