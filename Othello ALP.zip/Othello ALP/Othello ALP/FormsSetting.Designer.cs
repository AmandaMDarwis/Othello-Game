﻿namespace Othello_ALP
{
    partial class FormsSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormsSetting));
            label1 = new Label();
            txtNameP1 = new TextBox();
            txtNameP2 = new TextBox();
            label2 = new Label();
            btnStart = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(130, 104);
            label1.Name = "label1";
            label1.Size = new Size(239, 21);
            label1.TabIndex = 0;
            label1.Text = "Masukkan Nama Player 1 (Black)";
            // 
            // txtNameP1
            // 
            txtNameP1.Location = new Point(139, 139);
            txtNameP1.Name = "txtNameP1";
            txtNameP1.Size = new Size(223, 27);
            txtNameP1.TabIndex = 1;
            // 
            // txtNameP2
            // 
            txtNameP2.Location = new Point(138, 218);
            txtNameP2.Name = "txtNameP2";
            txtNameP2.Size = new Size(223, 27);
            txtNameP2.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(130, 183);
            label2.Name = "label2";
            label2.Size = new Size(246, 21);
            label2.TabIndex = 3;
            label2.Text = "Masukkan Nama Player 2 (White)";
            // 
            // btnStart
            // 
            btnStart.Font = new Font("Candara", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnStart.Location = new Point(199, 273);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(94, 29);
            btnStart.TabIndex = 6;
            btnStart.Text = "START";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.FlatStyle = FlatStyle.Popup;
            label3.Font = new Font("MV Boli", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.OldLace;
            label3.Location = new Point(178, 37);
            label3.Name = "label3";
            label3.Size = new Size(151, 49);
            label3.TabIndex = 8;
            label3.Text = "Othello";
            // 
            // FormsSetting
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(497, 373);
            Controls.Add(label3);
            Controls.Add(btnStart);
            Controls.Add(label2);
            Controls.Add(txtNameP2);
            Controls.Add(txtNameP1);
            Controls.Add(label1);
            MaximumSize = new Size(515, 420);
            Name = "FormsSetting";
            Text = "FormsSetting";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNameP1;
        private TextBox txtNameP2;
        private Label label2;
        private Button btnStart;
        private Label label3;
    }
}